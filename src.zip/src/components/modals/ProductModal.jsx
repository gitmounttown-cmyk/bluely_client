import React, { useState, useEffect } from 'react';

export default function ProductModal({ isOpen, onClose, onSave, editingProduct, categories }) {
  const [form, setForm] = useState({ name: '', category: '', price: '', stock: '' });

  useEffect(() => {
    if (editingProduct) {
      setForm(editingProduct);
    } else {
      setForm({ name: '', category: categories[0]?.name || '', price: '', stock: '' });
    }
  }, [editingProduct, categories]);

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(form);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl">
        <h3 className="text-lg font-bold text-gray-800 mb-4">{editingProduct ? 'Edit Product' : 'Add New Product'}</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Product Name</label>
            <input 
              type="text" required value={form.name} 
              onChange={e => setForm({...form, name: e.target.value})}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-bluely-500" 
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Category</label>
            <select 
              value={form.category} 
              onChange={e => setForm({...form, category: e.target.value})}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-bluely-500"
            >
              {categories.map(c => <option key={c._id || c.name} value={c.name}>{c.name}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Price (₹)</label>
              <input 
                type="number" required value={form.price} 
                onChange={e => setForm({...form, price: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-bluely-500" 
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Stock Quantity</label>
              <input 
                type="number" required value={form.stock} 
                onChange={e => setForm({...form, stock: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-bluely-500" 
              />
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600">Cancel</button>
            <button type="submit" className="px-4 py-2 text-sm font-semibold bg-bluely-500 text-white rounded-lg">Save Product</button>
          </div>
        </form>
      </div>
    </div>
  );
}