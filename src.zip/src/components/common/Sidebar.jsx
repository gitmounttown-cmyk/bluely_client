import React from 'react';
import './Sidebar.css'; // Direct CSS import
import { NavLink } from 'react-router-dom';

export default function Sidebar() {
  return (
    <aside className="sidebar-container">
      <div className="sidebar-header">BLUELY <span className="sidebar-badge">Admin</span></div>
      <nav className="sidebar-nav">
        <NavLink to="/" className={({isActive}) => isActive ? 'sidebar-link active' : 'sidebar-link'}>Dashboard</NavLink>
        <NavLink to="/categories" className={({isActive}) => isActive ? 'sidebar-link active' : 'sidebar-link'}>Categories</NavLink>
        <NavLink to="/inventory" className={({isActive}) => isActive ? 'sidebar-link active' : 'sidebar-link'}>Inventory Stock</NavLink>
        <NavLink to="/orders" className={({isActive}) => isActive ? 'sidebar-link active' : 'sidebar-link'}>Orders</NavLink>
        <NavLink to="/billing" className={({isActive}) => isActive ? 'sidebar-link active' : 'sidebar-link'}>Billing POS</NavLink>
      </nav>
    </aside>
  );
}