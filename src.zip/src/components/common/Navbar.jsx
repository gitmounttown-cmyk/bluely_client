import React from 'react';
import { useLocation } from 'react-router-dom';

export default function Navbar() {
  const location = useLocation();
  const titles = {
    '/': 'Dashboard Overview',
    '/categories': 'Category Management',
    '/inventory': 'Product Inventory Stock',
    '/orders': 'Customer Orders',
    '/billing': 'Billing & POS Terminal',
    '/dealers': 'Dealer Partnership Requests'
  };

  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 shadow-sm">
      <h2 className="text-lg font-semibold text-gray-700">{titles[location.pathname] || 'Admin Portal'}</h2>
      <div className="flex items-center gap-3 border-l pl-4 border-gray-200">
        <div className="w-9 h-9 bg-bluely-500 text-white rounded-full flex items-center font-bold justify-center">A</div>
        <div className="hidden sm:block">
          <p className="text-xs font-semibold leading-tight">Admin User</p>
          <p className="text-[10px] text-gray-500">admin@bluely.in</p>
        </div>
      </div>
    </header>
  );
}