import axiosClient from './axiosClient';

export const getProducts = () => axiosClient.get('/product'); //[cite: 3]
export const createProduct = (formData) => axiosClient.post('/product', formData, {
  headers: { 'Content-Type': 'multipart/form-data' }
});
export const updateProduct = (id, formData) => axiosClient.put(`/product/${id}`, formData, {
  headers: { 'Content-Type': 'multipart/form-data' }
});
export const deleteProduct = (id) => axiosClient.delete(`/product/${id}`);