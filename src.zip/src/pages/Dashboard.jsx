import React from 'react';
import './Dashboard.css'; // Direct CSS import
import StatCard from '../components/common/StatCard';

export default function Dashboard() {
  return (
    <div className="dashboard-container">
      <div className="dashboard-grid">
        {/* Render StatCards */}
      </div>
    </div>
  );
}