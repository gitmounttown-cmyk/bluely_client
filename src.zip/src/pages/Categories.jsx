import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Folders } from 'lucide-react';
import { getCategories, createCategory, updateCategory, deleteCategory } from '../api/categoryApi';
import CategoryModal from '../components/modals/CategoryModal';

export default function Categories() {
  const [categories, setCategories] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);

  const fetchCategories = async () => {
    try {
      const res = await getCategories();
      setCategories(res.data.categories || res.data);
    } catch {
      // Fallback mock state if backend not connected yet
      setCategories([
        { _id: '1', name: 'Laundry Care', description: 'Detergents and liquids' },
        { _id: '2', name: 'Floor Care', description: 'Floor and glass cleaners' },
        { _id: '3', name: 'Bathroom Care', description: 'Toilet cleaners' }
      ]);
    }
  };

  useEffect(() => { fetchCategories(); }, []);

  const handleSave = async (data) => {
    if (editingCategory) {
      await updateCategory(editingCategory._id, data).catch(() => {});
    } else {
      await createCategory(data).catch(() => {});
    }
    fetchCategories();
  };

  const handleDelete = async (id) => {
    if (confirm('Delete category?')) {
      await deleteCategory(id).catch(() => {});
      fetchCategories();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-gray-800">Product Categories</h2>
          <p className="text-xs text-gray-500">Organize cleaning solutions into structured categories.</p>
        </div>
        <button onClick={() => { setEditingCategory(null); setIsModalOpen(true); }} className="bg-bluely-500 hover:bg-bluely-600 text-white text-sm font-semibold px-4 py-2.5 rounded-lg flex items-center gap-2">
          <Plus size={16} /> Add Category
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {categories.map((cat) => (
          <div key={cat._id || cat.name} className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start">
                <h3 className="font-bold text-gray-800 text-base">{cat.name}</h3>
                <div className="flex gap-2">
                  <button onClick={() => { setEditingCategory(cat); setIsModalOpen(true); }} className="text-gray-400 hover:text-bluely-600"><Edit2 size={15} /></button>
                  <button onClick={() => handleDelete(cat._id)} className="text-gray-400 hover:text-red-600"><Trash2 size={15} /></button>
                </div>
              </div>
              <p className="text-gray-500 text-xs mt-1">{cat.description || 'No description provided'}</p>
            </div>
            <div className="mt-4 pt-3 border-t border-gray-50 flex items-center gap-2 text-xs text-bluely-600 font-semibold">
              <Folders size={14} /> Active Category Group
            </div>
          </div>
        ))}
      </div>

      <CategoryModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onSave={handleSave} 
        editingCategory={editingCategory} 
      />
    </div>
  );
}