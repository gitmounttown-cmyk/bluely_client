import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Sidebar from './components/common/Sidebar';
import Navbar from './components/common/Navbar';
import Dashboard from './pages/Dashboard';
import Categories from './pages/Categories';
import InventoryStock from './pages/InventoryStock';
import Orders from './pages/Orders';
import BillingPOS from './pages/BillingPOS';

export default function App() {
  return (
    <BrowserRouter>
      <div className="flex h-screen overflow-hidden bg-gray-50">
        <Sidebar />
        <div className="flex-1 flex flex-col overflow-y-auto">
          <Navbar />
          <main className="p-6">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/categories" element={<Categories />} />
              <Route path="/inventory" element={<InventoryStock />} />
              <Route path="/orders" element={<Orders />} />
              <Route path="/billing" element={<BillingPOS />} />
              <Route path="/dealers" element={<div className="text-lg font-bold">Dealer Requests Portal</div>} />
            </Routes>
          </main>
        </div>
      </div>
    </BrowserRouter>
  );
}